function getStringLength(str) {
    return str.length;
}

// Example usage
console.log(getStringLength("Hello, World!")); // Output: 13
console.log(getStringLength("JavaScript"));    // Output: 10
console.log(getStringLength(""));              // Output: 0
